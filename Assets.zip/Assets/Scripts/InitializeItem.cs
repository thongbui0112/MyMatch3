using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InitializeItem : MonoBehaviour {

    private void Start() {
        CreateItem();
    }

    private void CreateItem() {

    }


}
